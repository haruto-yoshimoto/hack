// カード表示をリッチにアニメーションで
function animateCards() {
    document.querySelectorAll(".card-visual:not(.animate-in)").forEach(card=>{
        setTimeout(()=>{ card.classList.add("animate-in"); }, 100);
    });
}

// コインアニメ：贅沢仕様
window.animateCoinReward = function(amount) {
    // 枚数制限なしで表示, コインの高級バージョン
    let field = document.createElement('div');
    field.className='coin-animate';

    let html = '';
    const maxCoins = Math.min(amount, 15);
    for(let i = 0; i < maxCoins; i++) {
        html += `
        <span class="coin-img premium" style="animation-delay:${i*40}ms">
            <span class="coin-face"></span>
            <span class="coin-glint"></span>
            <span class="coin-sparkle"></span>
        </span>
        `;
    }
    field.innerHTML = html;
    document.body.appendChild(field);
    setTimeout(()=>field.remove(), 1200);
    // サウンド
    let snd = document.createElement('audio');
    snd.src = "/static/sfx/coin.mp3";
    snd.autoplay=true;
    snd.volume=0.2;
    setTimeout(()=>snd.remove(), 1400);
    document.body.appendChild(snd);
};

// カードのHTML化
function cardToHTML(card, reveal=true) {
    if(!reveal) return `<div class="card-visual back"></div>`;
    const isRed = (card.suit==='♥'||card.suit==='♦');
    return `<div class="card-visual ${isRed?'red':'black'}">
        <span class="rank">${card.rank}</span>
        <span class="suit">${card.suit}</span>
    </div>`;
}

// ゲーム画面ロード時にアニメ実行
window.addEventListener('DOMContentLoaded', ()=>{
    animateCards();
    // コインアニメリストナー
    window.animateCoinReward = function(amount) {
        let field = document.createElement('div');
        field.className='coin-animate';
        field.innerHTML = Array(Math.min(amount,10)).fill(0).map(()=>"<span class='coin-img'></span>").join('');
        document.body.appendChild(field);
        setTimeout(()=>field.remove(),900);
        // サウンド
        let snd = document.createElement('audio');
        snd.src = "/static/sfx/coin.mp3";
        snd.autoplay=true;
        snd.volume=0.25;
        setTimeout(()=>snd.remove(),1000);
        document.body.appendChild(snd);
    };
});