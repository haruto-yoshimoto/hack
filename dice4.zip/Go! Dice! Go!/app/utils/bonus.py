from datetime import datetime, date, timedelta
from ..models import Task, User, PointHistory

def get_today_tasks(user_id):
    today = date.today()
    start = datetime.combine(today, datetime.min.time())
    end = datetime.combine(today, datetime.max.time())
    return Task.query.filter(
        Task.user_id == user_id,
        Task.created_at >= start,
        Task.created_at <= end,
        Task.is_done == True,
    ).all()

def all_tasks_cleared_3_today(user_id):
    tasks = get_today_tasks(user_id)
    done_tasks = [t for t in tasks if t.is_done]
    return len(done_tasks) >= 3

def check_and_grant_burst_protection(user_id):
    if not all_tasks_cleared_3_today(user_id):
        return

    # 今日すでにバースト無効券付与(type=8)があるか確認
    today = date.today()
    start = datetime.combine(today, datetime.min.time())
    end = datetime.combine(today, datetime.max.time())
    exists = PointHistory.query.filter(
        PointHistory.user_id == user_id,
        PointHistory.type == 8,
        PointHistory.created_at >= start,
        PointHistory.created_at <= end
    ).first()
    if exists:
        return

    # まだならバースト無効券付与
    user = User.query.get(user_id)
    if user:
        user.burst_protection = user.burst_protection + 1 if user.burst_protection else 1

        # type=8 で履歴も追加
        ph = PointHistory(
            user_id = user_id,
            point = 0,  # コイン増減なし
            type = 8,   # 独自定義
            created_at = datetime.now()
        )
        from .. import db
        db.session.add(ph)
        db.session.commit()

def is_bj_double_reward(user_id):
    today = date.today()
    for i in range(5):
        d = today - timedelta(days=i)
        start = datetime.combine(d, datetime.min.time())
        end = datetime.combine(d, datetime.max.time())
        tasks = Task.query.filter(
            Task.user_id == user_id, Task.created_at >= start, Task.created_at <= end, Task.is_deleted == False
        ).all()
        done_tasks = [t for t in tasks if t.is_done]
        if len(done_tasks) < 3:
            return False
    return True
