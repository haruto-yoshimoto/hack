import random

def create_deck():
    ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    suits = ['♠', '♥', '♦', '♣']
    deck = [{'rank': r, 'suit': s} for r in ranks for s in suits]
    random.shuffle(deck)
    return deck

def calculate_score(hand):
    score = 0
    aces = 0
    for card in hand:
        r = card['rank']
        if r in ['J', 'Q', 'K']:
            score += 10
        elif r == 'A':
            score += 11
            aces += 1
        else:
            score += int(r)
    while score > 21 and aces:
        score -= 10
        aces -= 1
    return score