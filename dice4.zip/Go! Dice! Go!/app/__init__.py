from flask import Flask
from .models import db

def create_app():
    from .models import db
    app = Flask(__name__)

    # ここで設定値、DB初期化
    app.config.from_object('config.Config')
    db.init_app(app)

    # Blueprint登録
    from .views.todo import todo_bp
    from .views.user import user_bp
    from .views.gamble import gamble_bp
    app.register_blueprint(todo_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(gamble_bp)

    # DBテーブル作成
    with app.app_context():
        db.create_all()

    return app