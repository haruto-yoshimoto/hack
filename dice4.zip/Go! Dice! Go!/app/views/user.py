from flask import Blueprint, render_template, request, redirect, url_for, session
from ..models import db, User
from werkzeug.security import generate_password_hash, check_password_hash

user_bp = Blueprint('user', __name__)

@user_bp.route('/register', methods=['GET', 'POST'])
def register_page():
    if request.method == 'GET':
        return render_template('user_register.html')
    username = request.form['username']
    password = request.form['password']
    if not username or not password:
        return "ユーザー名とパスワードは必須です", 400
    if User.query.filter_by(username=username).first():
        return "このユーザー名は既に使われています", 400
    user = User(username=username, password_hash=generate_password_hash(password), coins=0, burst_protection=0)
    db.session.add(user)
    db.session.commit()
    return redirect(url_for('user.login_page'))

@user_bp.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'GET':
        return render_template('login.html')
    username = request.form['username']
    password = request.form['password']
    user = User.query.filter_by(username=username).first()
    if user and check_password_hash(user.password_hash, password):
        session['user_id'] = user.id
        return redirect(url_for('todo.home'))
    else:
        return "ユーザー名またはパスワードが違います", 401

@user_bp.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('user.login_page'))

@user_bp.route('/user_info')
def user_info():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    user = User.query.get(session['user_id'])
    if user is None:
        session.pop('user_id', None)
        return redirect(url_for('user.login_page'))
    return render_template('user_info.html', user=user)