from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from datetime import datetime
from ..models import db, User, GambleHistory, PointHistory, Task
from ..utils.blackjack import create_deck, calculate_score
from ..utils.bonus import is_bj_double_reward

gamble_bp = Blueprint('gamble', __name__)

@gamble_bp.route('/gamble', methods=['GET'])
def gamble_top():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    user = User.query.get(session['user_id'])
    return render_template('bet_gamble.html', coins=user.coins, message=None)

@gamble_bp.route('/gamble/bet', methods=['POST'])
def gamble_bet():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    user = User.query.get(session['user_id'])
    try:
        bet = int(request.form['bet'])
    except:
        bet = 0
    if bet < 1 or bet > user.coins:
        return render_template('bet_gamble.html', coins=user.coins, message="有効な賭け金を入力してください")
    deck = create_deck()
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]
    session['bk_deck'] = deck
    session['bk_player_hand'] = player_hand
    session['bk_dealer_hand'] = dealer_hand
    session['bk_game_over'] = False
    session['bk_bet'] = bet
    session['bk_result'] = ''
    session['bk_first_turn'] = True  # ダブルダウン用

    player_score = calculate_score(player_hand)
    dealer_score = calculate_score(dealer_hand)

    bj_double = is_bj_double_reward(user.id)
    # 各ブラックジャック判定部
    if player_score == 21:
        session['bk_game_over'] = True
        if dealer_score == 21:
            # 引き分け（ダブルブラックジャック）
            session['bk_result'] = '引き分け（ダブルブラックジャック）'
            session['bk_celebration'] = False  # ★セレブなし
            db.session.add(PointHistory(user_id=user.id, point=0, type=7, created_at=datetime.now()))
            db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=None, gamble_date=datetime.now()))
        else:
            # ユーザーBJ勝利!
            session['bk_result'] = f'ブラックジャック！（{"5" if bj_double else "2"}倍の配当）'
            session['bk_celebration'] = True   # ★セレブあり
            reward = int(bet * (5 if bj_double else 2))
            user.coins += reward
            db.session.add(PointHistory(user_id=user.id, point=reward, type=5, created_at=datetime.now()))
            db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=True, gamble_date=datetime.now()))
        db.session.commit()
        return redirect(url_for('gamble.gamble_result'))
    elif dealer_score == 21:
        session['bk_game_over'] = True
        session['bk_result'] = 'ディーラーブラックジャック！（あなたの負け）'
        session['bk_celebration'] = False      # ★セレブなし
        user.coins -= bet
        db.session.add(PointHistory(user_id=user.id, point=-bet, type=6, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=False, gamble_date=datetime.now()))
        db.session.commit()
        return redirect(url_for('gamble.gamble_result'))
    return redirect(url_for('gamble.gamble_game'))

@gamble_bp.route('/gamble/game')
def gamble_game():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    player_hand = session['bk_player_hand']
    dealer_hand = session['bk_dealer_hand']
    bet = session['bk_bet']
    user = User.query.get(session['user_id'])
    game_over = session.get('bk_game_over', False)
    result = session.get('bk_result', '')
    show_dealer_hand = dealer_hand if game_over else [dealer_hand[0]]
    return render_template(
        'game_gamble.html',
        player_hand=player_hand,
        dealer_hand=show_dealer_hand,
        player_score=calculate_score(player_hand),
        dealer_score='?' if not game_over else calculate_score(dealer_hand),
        game_over=game_over,
        result=result,
        coins=user.coins,
        bet=bet
    )

@gamble_bp.route('/gamble/hit')
def gamble_hit():
    player_hand = session['bk_player_hand']
    deck = session['bk_deck']
    player_hand.append(deck.pop())
    session['bk_player_hand'] = player_hand
    session['bk_deck'] = deck
    score = calculate_score(player_hand)
    user = User.query.get(session['user_id'])
    if score > 21:
        if user.burst_protection and user.burst_protection > 0:
            session['bk_before_burst_hand'] = player_hand[:-1]
            session['bk_burst_card'] = player_hand[-1]
            return redirect(url_for('gamble.burst_protection_popup'))
        else:
            session['bk_game_over'] = True
            session['bk_result'] = 'バースト！あなたの負け'
            user.coins -= session['bk_bet']
            db.session.add(PointHistory(user_id=user.id, point=-session['bk_bet'], type=3, created_at=datetime.now()))
            db.session.add(GambleHistory(user_id=user.id, bet_point=session['bk_bet'], result=False, gamble_date=datetime.now()))
            db.session.commit()
            return redirect(url_for('gamble.gamble_result'))
    session['bk_first_turn'] = False
    return redirect(url_for('gamble.gamble_game'))

@gamble_bp.route('/gamble/stand')
def gamble_stand():
    deck = session['bk_deck']
    dealer_hand = session['bk_dealer_hand']
    user = User.query.get(session['user_id'])
    stand_point = 17

    while calculate_score(dealer_hand) <= stand_point:
        dealer_hand.append(deck.pop())
    session['bk_dealer_hand'] = dealer_hand

    player_score = calculate_score(session['bk_player_hand'])
    dealer_score = calculate_score(dealer_hand)
    bet = session['bk_bet']

    bj_double = is_bj_double_reward(user.id)
    game_reward = bet * (2 if bj_double and player_score > dealer_score and player_score <= 21 else 1)

    if dealer_score > 21:
        session['bk_result'] = 'ディーラーバースト！あなたの勝ち'
        user.coins += game_reward
        db.session.add(PointHistory(user_id=user.id, point=game_reward, type=2, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=True, gamble_date=datetime.now()))
    elif dealer_score > player_score:
        session['bk_result'] = 'あなたの負け'
        user.coins -= bet
        db.session.add(PointHistory(user_id=user.id, point=-bet, type=3, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=False, gamble_date=datetime.now()))
    elif dealer_score < player_score:
        session['bk_result'] = 'あなたの勝ち'
        user.coins += game_reward
        db.session.add(PointHistory(user_id=user.id, point=game_reward, type=2, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=True, gamble_date=datetime.now()))
    else:
        session['bk_result'] = '引き分け'
        db.session.add(PointHistory(user_id=user.id, point=0, type=4, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=None, gamble_date=datetime.now()))
    session['bk_game_over'] = True
    db.session.commit()
    return redirect(url_for('gamble.gamble_result'))

@gamble_bp.route('/gamble/doubledown')
def gamble_doubledown():
    if not session.get('bk_first_turn'):
        return redirect(url_for('gamble.gamble_game'))

    bet = session['bk_bet']
    user = User.query.get(session['user_id'])
    if user.coins < bet:
        session['bk_result'] = 'コインが足りません'
        session['bk_game_over'] = True
        return redirect(url_for('gamble.gamble_result'))
    user.coins -= bet
    db.session.commit()
    session['bk_bet'] = bet * 2

    deck = session['bk_deck']
    player_hand = session['bk_player_hand']
    player_hand.append(deck.pop())
    session['bk_player_hand'] = player_hand
    session['bk_deck'] = deck
    session['bk_first_turn'] = False

    return redirect(url_for('gamble.gamble_stand'))

@gamble_bp.route('/gamble/result')
def gamble_result():
    user = User.query.get(session['user_id'])
    player_hand = session.get('bk_player_hand', [])
    dealer_hand = session.get('bk_dealer_hand', [])
    player_score = calculate_score(player_hand)
    dealer_score = calculate_score(dealer_hand)
    result = session.get('bk_result', '')
    coins = user.coins
    bet = session.get('bk_bet', 1)
    game_over = session.get('bk_game_over', True)
    celebration = session.get('bk_celebration', False)  # ★追加

    # ↓★ここで「コイン演出出すべきか」を計算
    show_coin_anim = False
    # 勝ち/ブラックジャック勝ちの場合のみTrue
    if '勝ち' in result or (result.startswith('ブラックジャック') and not result.startswith('ディーラーブラックジャック')):
        show_coin_anim = True

    return render_template(
        'game_gamble.html',
        player_hand=player_hand,
        dealer_hand=dealer_hand,
        player_score=player_score,
        dealer_score=dealer_score,
        game_over=game_over,
        result=result,
        coins=coins,
        bet=bet,
        celebration=celebration,  # ★追加
        show_coin_anim=show_coin_anim  # ★追加
    )

@gamble_bp.route('/burst_popup')
def burst_protection_popup():
    return render_template('burst_popup.html')

@gamble_bp.route('/burst_protection_use', methods=['POST'])
def burst_protection_use():
    user = User.query.get(session['user_id'])
    action = request.form.get('action')
    if action == 'yes':
        if user.burst_protection > 0:
            user.burst_protection -= 1
            db.session.commit()
        session['bk_player_hand'] = session.get('bk_before_burst_hand', [])
        flash('バースト無効券を使い、手番は元に戻りました！')
        return redirect(url_for('gamble.gamble_game'))
    else:
        bet = session['bk_bet']
        user.coins -= bet
        db.session.add(PointHistory(user_id=user.id, point=-bet, type=3, created_at=datetime.now()))
        db.session.add(GambleHistory(user_id=user.id, bet_point=bet, result=False, gamble_date=datetime.now()))
        session['bk_game_over'] = True
        session['bk_result'] = 'バースト！あなたの負け'
        db.session.commit()
        return redirect(url_for('gamble.gamble_result'))

@gamble_bp.route('/gamble_history')
def gamble_history():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    history = GambleHistory.query.filter_by(user_id=session['user_id']).order_by(GambleHistory.gamble_date.desc()).all()
    return render_template('gamble_history.html', histories=history)

@gamble_bp.route('/point_history')
def point_history():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    history = PointHistory.query.filter_by(user_id=session['user_id']).order_by(PointHistory.created_at.desc()).all()
    return render_template('point_history.html', histories=history)