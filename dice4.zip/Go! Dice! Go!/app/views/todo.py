from flask import Blueprint, render_template, request, redirect, url_for, session
from ..models import db, Task, User, PointHistory
from datetime import datetime
from ..utils.bonus import check_and_grant_burst_protection, all_tasks_cleared_3_today, is_bj_double_reward

todo_bp = Blueprint('todo', __name__)

@todo_bp.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    user = User.query.get(session['user_id'])
    if user is None:
        session.pop('user_id', None)
        return redirect(url_for('user.login_page'))
    tasks = Task.query.filter_by(user_id=user.id, is_deleted=False).all()
    coins = user.coins if user.coins is not None else 0
    burst_protection = user.burst_protection if user.burst_protection else 0
    bj_double_reward = is_bj_double_reward(user.id)
    all_tasks_cleared = all_tasks_cleared_3_today(user.id)
    return render_template(
        'index.html',
        tasks=tasks,
        coins=coins,
        burst_protection=burst_protection,
        bj_double_reward=bj_double_reward,
        all_tasks_cleared_3_today=all_tasks_cleared
    )

@todo_bp.route('/tasks', methods=['POST'])
def add_task():
    if 'user_id' not in session:
        return redirect(url_for('user.login_page'))
    title = request.form['title']
    contents = request.form['content']
    difficulty = int(request.form['difficulty'])
    task = Task(
        user_id=session['user_id'],
        title=title,
        contents=contents,
        is_done=False,
        created_at=datetime.now(),
        task_diff=difficulty
    )
    db.session.add(task)
    db.session.commit()
    return redirect(url_for('todo.home'))

@todo_bp.route('/complete_task/<int:task_id>', methods=['POST'])
def complete_task(task_id):
    task = Task.query.get(task_id)
    if task and task.user_id == session.get('user_id') and not task.is_done:
        task.is_done = True
        task.done_at = datetime.now()
        diff_reward = {1: 10, 2: 30, 3: 50}
        user = User.query.get(session.get('user_id'))
        add_coin = diff_reward.get(task.task_diff, 10)
        user.coins += add_coin

        # ポイント履歴追加
        point_history = PointHistory(
            user_id=user.id,
            point=add_coin,
            type=1,  # タスク達成
            created_at=datetime.now()
        )
        db.session.add(point_history)
        db.session.commit()

        # 今日3つ全消化ならバースト無効券付与
        check_and_grant_burst_protection(user.id)
    return redirect(url_for('todo.home'))

@todo_bp.route('/delete_task/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    task = Task.query.get(task_id)
    if task and task.user_id == session.get('user_id'):
        task.is_deleted = True
        db.session.commit()
    return redirect(url_for('todo.home'))