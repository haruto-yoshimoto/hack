from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    coins = db.Column(db.Integer, default=0)
    burst_protection = db.Column(db.Integer, default=0)  # バースト無効券

class Task(db.Model):
    __tablename__ = 'task'
    task_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(30), nullable=False)
    contents = db.Column(db.String(200), nullable=False)
    is_done = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    done_at = db.Column(db.DateTime, nullable=True)
    task_diff = db.Column(db.Integer)
    is_deleted = db.Column(db.Boolean, default=False)

class GambleHistory(db.Model):
    __tablename__ = 'gamble_history'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    bet_point = db.Column(db.Integer)
    result = db.Column(db.Boolean)
    gamble_date = db.Column(db.DateTime, default=datetime.now)

class PointHistory(db.Model):
    __tablename__ = 'point_history'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    point = db.Column(db.Integer)
    type = db.Column(db.Integer)  # 1:タスク,2:勝ち,3:負け,4:引き分け,5:BJ3倍,6:BJ負け,7:ドロー
    created_at = db.Column(db.DateTime, default=datetime.now)