from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    coins = db.Column(db.Integer, default=0)
    burst_protection = db.Column(db.Integer, default=0)

class Task(db.Model):
    __tablename__ = 'task'
    task_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(30), nullable=False)
    contents = db.Column(db.String(200), nullable=False)
    is_done = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    done_at = db.Column(db.DateTime, nullable=True)
    task_diff = db.Column(db.Integer)
    is_deleted = db.Column(db.Boolean, default=False)   # ←ここを必ず追加

def create_user_and_tasks():
    # user_id=1のユーザーが存在しなければ作成
    user = User.query.filter_by(id=1).first()
    if not user:
        user = User(
            username='testuser',
            password_hash=generate_password_hash('testpass'),
            coins=100
        )
        db.session.add(user)
        db.session.commit()

    today = datetime.now()
    for day_idx in range(5):  # 5日分
        day = today - timedelta(days=(4 - day_idx))
        for t in range(3):   # 1日に3つタスク
            created_at = day.replace(hour=10+t*2, minute=0, second=0, microsecond=0)
            done_at = day.replace(hour=12+t*4, minute=30, second=0, microsecond=0)
            task = Task(
                user_id=user.id,
                title=f"連続タスク{day_idx+1}-{t+1}",
                contents=f"{day_idx+1}日目の{t+1}番目の完了タスクです。",
                task_diff=random.choice([1,2,3]),
                is_done=True,
                created_at=created_at,
                done_at=done_at,
                is_deleted=False    # ← この一行を追加
            )
            db.session.add(task)
    db.session.commit()
    print("5日間×3件=15件の完了タスクを追加しました")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()  # テーブルがまだなら作成
        create_user_and_tasks()